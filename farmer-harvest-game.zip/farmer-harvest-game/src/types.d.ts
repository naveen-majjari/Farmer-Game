// JSDoc typedef helpers (used by editors for intellisense)
/** @typedef {{x:number,y:number}} Vec2 */
/** @typedef {{x:number,y:number,w:number,h:number}} Rect */
